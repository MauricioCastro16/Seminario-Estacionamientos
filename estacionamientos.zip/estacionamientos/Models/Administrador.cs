namespace estacionamientos.Models
{
    public class Administrador : Usuario
    {
        // No tiene campos adicionales, solo hereda de Usuario
    }
}
