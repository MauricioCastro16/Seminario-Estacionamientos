using System.ComponentModel.DataAnnotations;

namespace estacionamientos.Models
{
    // Hereda toda la info de Usuario
    public class Playero : Usuario
    {
        // Sin campos adicionales por ahora
    }
}
