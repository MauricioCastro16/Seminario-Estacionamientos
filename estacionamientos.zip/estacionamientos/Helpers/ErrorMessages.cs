namespace estacionamientos.Helpers
{
    public static class ErrorMessages
    {
        public const string CampoObligatorio = "* Este campo es obligatorio";
    }
}