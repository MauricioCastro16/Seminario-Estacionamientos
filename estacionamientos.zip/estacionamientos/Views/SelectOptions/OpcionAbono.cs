namespace estacionamientos.ViewModels.SelectOptions
{
    public class OpcionAbono
    {
        public DateTime AboFyhIni { get; set; }
        public string Texto { get; set; } = string.Empty;
    }
}
