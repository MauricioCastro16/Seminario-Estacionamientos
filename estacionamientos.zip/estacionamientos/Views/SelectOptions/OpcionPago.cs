namespace estacionamientos.ViewModels.SelectOptions
{
    public class OpcionPago
    {
        public int PagNum { get; set; }
        public string Texto { get; set; } = string.Empty; // ej: "123 - 12/08/2025 10:32"
    }
}
