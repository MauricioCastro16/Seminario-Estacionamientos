namespace estacionamientos.ViewModels.SelectOptions
{
    public class OpcionPlaza
    {
        public int PlzNum { get; set; }
    }
}
